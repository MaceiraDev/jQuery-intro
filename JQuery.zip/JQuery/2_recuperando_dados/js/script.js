$(document).ready(function(){
    //adcionando html
    $('.element').html("Meu texto via jQuery");

    //add css
    $("#lista").css("color", "red");

    //disparar no click
    $("a").click(function(){
        alert("Olá Mundo")
    })
});

//criando função
    function pegarvalor(){
        var nome = document.querySelector('.nome').value;
        var sobrenome = document.querySelector('.sobrenome').value;

        alert(nome + " " + sobrenome);
             }